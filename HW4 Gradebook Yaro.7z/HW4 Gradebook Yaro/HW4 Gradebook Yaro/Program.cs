﻿using System;

namespace HW4_Gradebook_Yaro
{
    class Program
    {
        static void Main(string[] args)
        {
            int TotalGrades;

            // The arrays will be initialized after user input

            Console.WriteLine("How many total grades would you like to store: ");
            TotalGrades = int.Parse(Console.ReadLine());
            while(TotalGrades < 0)
            {
                Console.WriteLine("Invalid input, try again: ");
                TotalGrades = int.Parse(Console.ReadLine());
            }

            double[] GradesArray = new double[TotalGrades];
            string[] AssignmentNames = new string[TotalGrades];

            // Loop below assigns all the data to their appropriate arrays

            for (int i = 0; i < TotalGrades; i++)
            {
                Console.WriteLine("What is the name of the assignment {0}: ", i + 1);
                AssignmentNames[i] = Console.ReadLine();
                Console.WriteLine("What is the grade of assignment {0}: ", i + 1);
                GradesArray[i] = double.Parse(Console.ReadLine());
                while (GradesArray[i] < 0 || GradesArray[i] > 100)
                {
                    Console.WriteLine("Invalid input, try again: ");
                    GradesArray[i] = double.Parse(Console.ReadLine());
                }
            }

            // Loop below prints out the grade report with the grade average

            Console.WriteLine("\nGradebook: ");

            double TotalSumOfGrades = 0;
            double GradeAvg = 0;

            for (int i = 0; i < TotalGrades; i++)
            {
                Console.WriteLine("{0}) {1}: {2}", i + 1, AssignmentNames[i], GradesArray[i]);
                TotalSumOfGrades = TotalSumOfGrades + GradesArray[i];
            }

            GradeAvg = TotalSumOfGrades / TotalGrades;

            Console.WriteLine("\nFinal average: {0}", GradeAvg);

            // Replacement of the appropriate index below

            Console.WriteLine("\nWhat is the index of the grade you'd like to replace: ");
            int index = int.Parse(Console.ReadLine());

            while(index < 1 || index > TotalGrades)
            {
                Console.WriteLine("Invalid input, try again: ");
                index = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("\nWhat is the new grade you'd like to note down: ");
            int newGrade = int.Parse(Console.ReadLine());

            index = index - 1;

            GradesArray[index] = newGrade;

            Console.WriteLine("\n");

            // New final grade average

            for (int i = 0; i < TotalGrades; i++)
            {
                Console.WriteLine("{0}) {1}: {2}", i + 1, AssignmentNames[i], GradesArray[i]);
                TotalSumOfGrades = TotalSumOfGrades + GradesArray[i];
            }

            GradeAvg = TotalSumOfGrades / TotalGrades;

            Console.WriteLine("\nFinal average: {0}", GradeAvg);

        }
    }
}
