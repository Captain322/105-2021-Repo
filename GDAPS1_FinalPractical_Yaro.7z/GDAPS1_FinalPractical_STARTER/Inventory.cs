﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GDAPS1_FinalPractical
{
    class Inventory
    {
        public List<Item> items = new List<Item>();
        public Item Item { get; set; }
        public void AddItem(Item item)
        {
            items.Add(item);

        }
        public void PrintSummary()
        {
            Console.WriteLine("The total number of items in your inventory is {0}", items.Count, ":");
            Console.WriteLine("\n");

            for (int i = 0; i < items.Count; i++)
            {
                Console.WriteLine("\t " + items[i]);
            }

            double TotalWeight = 0;
            int TotalDamage = 0;

            foreach(Item item in items)
            {
                TotalWeight = item.Weight + TotalWeight;
            }

            Console.WriteLine("Your total weight is: {0}", TotalWeight);
            foreach (Weapon item in items)
                try
                {
                    {
                        TotalDamage = item.Damage + TotalDamage;
                    }
                    Console.WriteLine("Your total damage with all your weapons is: {0}", TotalDamage);
                }
                catch(Exception I)
                {
                    continue;
                }

            // I'm not sure how to tell C# to only look for a weapon type object in the items list
            // or how to simply ignore non-weapon items and only take damage from weapons


            Console.WriteLine("Your total damage with all your weapons is: {0}", TotalDamage);

            /*
            public void LoadItems(string items.txt)
            {
                StreamReader reader =
                    new StreamReader( “.. / .. / .. / .. / items.txt” );
                    string item = reader.Readline();
                    while(item != null)
                        {
                          string item = reader.Readline();
                          Console.WriteLine(item)  
                        }
            }
            */

        }
    }
}
