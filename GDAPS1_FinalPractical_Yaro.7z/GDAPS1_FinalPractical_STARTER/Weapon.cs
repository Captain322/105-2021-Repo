﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GDAPS1_FinalPractical
{
    public class Weapon : Item
    {
        private double weight;
        private int damage;

        public override double Weight { get { return weight; } }

        public int Damage { get { return damage; } }

        public Weapon(string name, int damage, double weight):base(name)
        {
            this.weight = weight;
            this.damage = damage;
        }

        public override string ToString()
        {
            return string.Format
                ("{0}: {1} damage, {2} lbs ", Name, damage, weight);
        }
    }
}
