﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GDAPS1_FinalPractical
{
    class Food : Item
    {
        private int NumServings;
        private double lbsPerServing;

        public override double Weight { get { return NumServings * lbsPerServing; } }

        public Food(string name, int NumServings, double lbsPerServing) : base(name)
        {
            this.NumServings = NumServings;
            this.lbsPerServing = lbsPerServing;
        }

        public override string ToString()
        {
            return string.Format
                ("{0}: {1} lbs, {2} servings ", Name, Weight, NumServings);
        }

        public void Eat()
        {
            while (NumServings != 0)
            {
                Console.WriteLine("Mmmm, I ate a serving of APPLE!");
                NumServings = NumServings - 1;
            }
            if (Weight == 0)
                Console.WriteLine("No more APPLE :( ");
        }
    }
}
